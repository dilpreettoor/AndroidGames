package com.madt.sree.rockpaperscissors;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class ResultActivity extends AppCompatActivity {

    static int num;
    static String cpu_choice;

    TextView t1;
    Button ans;
    String result;

// need to get data from firebase

    String choice1 = "rock";
    String choice2 = "paper";
    String choice3 = "paper";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        t1 = (TextView) findViewById(R.id.txtresult);
        getresult();

    }

    void getresult()
    {

        if(choice1 == choice2 && choice1 == choice3) {
            result = "Draw !!!";
            t1.setText(result);
        }

        else if (choice1 != choice2 && choice1 != choice3 && choice2 != choice3){
            result = "Draw !!!";

            t1.setText(result);
        }

        else if (choice1 == choice2 && choice1 != choice3)
        {

            if ((choice1 == "rock" && choice3 == "paper" ) || (choice1 == "scissor" && choice3 == "rock" ) || (choice1 == "paper" && choice3 == "scissor" )  )
            {
                t1.setText("choice 3 winner");
            }
            else if (choice1 == "rock" && choice3 == "scissor" )
            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }
            else if (choice1 == "scissor" && choice3 == "paper")

            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }

            else if (choice1 == "paper" && choice3 == "rock")

            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }

        }




        else if (choice1 == choice3 && choice1 != choice2)
        {

            if ((choice1 == "rock" && choice2 == "paper" ) || (choice1 == "scissor" && choice2 == "rock" ) || (choice1 == "paper" && choice3 == "scissor" )  )
            {
                t1.setText("choice 2 winner");
            }
            else if (choice1 == "rock" && choice2 == "scissor" )
            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }
            else if (choice1 == "scissor" && choice2 == "paper")

            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }

            else if (choice1 == "paper" && choice2 == "rock")

            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..
                t1.setText("REMATCH.............");

            }

        }




        else if (choice2 == choice3 && choice1 != choice2)
        {

            if ((choice2 == "rock" && choice1 == "paper" ) || (choice2 == "scissor" && choice1 == "rock" ) || (choice2 == "paper" && choice1 == "scissor" )  )
            {
                t1.setText("choice 1 winner");
            }
            else if (choice2 == "rock" && choice1 == "scissor" )
            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }
            else if (choice2 == "scissor" && choice1 == "paper")

            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }

            else if (choice2 == "paper" && choice1 == "rock")

            {

                // rematch

                // remove choice 3 player from firebase using  .delete row id == 3

                // flag  = 0

                //  redirect to shaking screen..

                t1.setText("REMATCH.............");

            }

        }


    }


}